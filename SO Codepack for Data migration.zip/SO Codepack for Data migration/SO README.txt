
DB Object Migration		--For DBA

Step 1: Move migration codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Execute the script DB_DEPLOY.sh using PuTTY.
Step 4: Execute the script XXAWR_SF_SO_RSV_REL_CP.sh using PuTTY.


Configuration --Application Support Team

Step 1: Upon successful completion of DB Object Migration, access the Oracle application. 
Navigate to the System Administrator responsibility and allocate "AWRL SF Sales Order Reservation Release" to the
Group "OM Concurrent Programs"  and application "Order Management" responsibility.

Uploading RDF File into Custom Top Location
Step 1: Navigate to $XXAAC_TOP/Reports/US path in UNIX Server.
Step 2: Move "XXAWRL_Pick_slip.rdf" to this custom location.


In case of any failures, please reach out to sandeep.khatri@intelloger.com.
