/*# !/bin/bash
# ====================================================================
#                        AW Rostamani                              
#                           Dubai                                   
# ====================================================================
# $Header:$                                                          
# Description      : Script to create Staging table for Product Inventory Stocks in XXAAC Schema 
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0      01-05-24      Intelloger          Initial Draft              
# ==================================================================== 
*/
--WHENEVER SQLERROR CONTINUE;
SET HEADING OFF
SET TERM ON
SET SHOW OFF
SET VERIFY OFF
rem ******************************************************
rem  Accepting the appropriate variables to the arguments*
rem ******************************************************
COLUMN appsuser    NEW_VALUE APPS_LOGIN        NOPRINT
COLUMN appspwd     NEW_VALUE APPS_PWD          NOPRINT 
COLUMN xxaacuser   NEW_VALUE XXAAC_LOGIN       NOPRINT
COLUMN xxaacpwd    NEW_VALUE XXAAC_PWD         NOPRINT 
COLUMN tsname      NEW_VALUE TS_NAME           NOPRINT
COLUMN idxname     NEW_VALUE IDX_NAME          NOPRINT 
SELECT '&&1' appsuser 
     ,'&&2' appspwd
     ,'&&3' xxaacuser
     ,'&&4' xxaacpwd
     ,'&&5' tsname
     ,'&&6' idxname
FROM   dual
/
-----------------------------------------------------------
PROMPT connecting apps for tables, sequence and synonym.
-----------------------------------------------------------
conn &1/&2
/
PROMPT create table XXAAC.XXAWR_INV_ONHAND_IMPORT_STG
	CREATE TABLE XXAAC.XXAWR_INV_ONHAND_IMPORT_STG
(
inventory_item_id 					number
, item_code 						varchar2(300)
, primary_uom_code					varchar2(20)
, transaction_quantity 				number
, available_to_reserved_qty 		number
, primary_transaction_quantity 		number
, sf_product_id 					varchar2(1000)
, lot_number 						varchar2(80)
)
/
PROMPT upgrade table XXAWR_INV_ONHAND_IMPORT_STG
BEGIN
 ad_zd_table.upgrade('XXAAC','XXAWR_INV_ONHAND_IMPORT_STG');
END; 
/
PROMPT create table APPS.XXAWR_INV_ONHAND_CHANGE_STG
CREATE TABLE  APPS.XXAWR_INV_ONHAND_CHANGE_STG
(
OIC_INSTANCE_ID 				Varchar2(4000)
,RECORD_ID                            NUMBER       generated always as identity(start with 1 increment by 1 )
,inventory_item_id 				number
, item_code 						varchar2(300)
, primary_uom_code 				varchar2(20)
, transaction_quantity 			number
, available_to_reserved_qty 		number
, primary_transaction_quantity 	number
, sf_product_id 					varchar2(1000)
,STATUS_FLAG 					varchar2(10)
,SF_SYNC_FLAG   					varchar2(10)
,ERROR_MSG 						varchar2(4000)
,LAST_UPDATION_DATE 				DATE
,lot_number 						varchar2(80)
)
/
SHOW ERROR; 
EXIT;