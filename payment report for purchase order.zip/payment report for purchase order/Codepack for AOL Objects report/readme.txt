----------Codepack Execution Details
/*
             Owner        - DBA
             Server       - Production UNIX Server
             Directory    - $HOME
             Permissiions - 0775
---------------------------------*/



AOL Object Migration	--For DBA
Step 1: Move migration codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Execute the script Payment_Report_For_Purchase_Order.sh using PuTTY.
Step 4: Upon successful completion of steps 1 access the Oracle application.
 
 
Configuration --Application Support Team
 
Step 1: Upon successful completion of DB Object Migration, access the Oracle application. 
Navigate to the System Administrator responsibility and allocate "AWRL Payment Report For Purchase Order" to the
Group "All Reports"  and application "Purchasing" responsibility.

Uploading xml and rtf file in data defination and data template respectively

Step1: Navigate to "XML Publisher" responsibility from Oracle application.
Step2: Open Data Definition.
Step3: Search the data Definition by data defination code("XXAWR_PO_REPORT").
Step4: Upload Xml file "XXAWRL_Payment_Report_For_Purc_xml.xml" into the data definition.
Step5: Save the changes .
Step6: Click on data template tab and search based on data definition code("XXAWR_PO_REPORT").
Step7: Upadate data template("XXAWRL_Payment_Report_For_Purc_template.xls").
Step8: Save the changes. 

 
In case of any failures, please reach out to rachit.panwar@intelloger.com