/*# !/bin/bash
# ====================================================================
#                        AW Rostamani                              
#                           Dubai                                   
# ====================================================================
# $Header:$                                                          
# Description      : Script to create Database Objects for PO-WO 
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0      7-03-24      Intelloger         Initial Draft              
# ==================================================================== 
*/
--WHENEVER SQLERROR CONTINUE;
SET HEADING OFF
SET TERM ON
SET SHOW OFF
SET VERIFY OFF
rem ******************************************************
rem  Accepting the appropriate variables to the arguments*
rem ******************************************************
COLUMN appsuser    NEW_VALUE APPS_LOGIN        NOPRINT
COLUMN appspwd     NEW_VALUE APPS_PWD          NOPRINT 
COLUMN xxaacuser   NEW_VALUE XXAAC_LOGIN       NOPRINT
COLUMN xxaacpwd    NEW_VALUE XXAAC_PWD         NOPRINT 
COLUMN tsname      NEW_VALUE TS_NAME           NOPRINT
COLUMN idxname     NEW_VALUE IDX_NAME          NOPRINT 
SELECT '&&1' appsuser 
     ,'&&2' appspwd
     ,'&&3' xxaacuser
     ,'&&4' xxaacpwd
     ,'&&5' tsname
     ,'&&6' idxname
FROM   dual
/
-----------------------------------------------------------
PROMPT connecting apps for tables, sequence and synonym.
-----------------------------------------------------------
conn &1/&2
/
PROMPT create table XXAAC.XXAWR_PO_WO_REQUEST_STAGING

CREATE TABLE XXAAC.XXAWR_PO_WO_REQUEST_STAGING
(
  RECORD_ID                           NUMBER    GENERATED ALWAYS AS IDENTITY( START WITH 1 INCREMENT BY 1),
  OIC_INSTANCE_ID                     VARCHAR2(1000 BYTE),
  SF_PO_WO_REQUEST_NUMBER             VARCHAR2(240 BYTE),
  SF_PO_WO_REQUEST_ID                 VARCHAR2(240 BYTE),
  SF_REQUEST_DATE                     DATE,
  SALES_ORDER_NUMBER                  VARCHAR2(240 BYTE),
  SALES_ORDER_LINE_NUMBER             VARCHAR2(240 BYTE),
  ITEM_CODE                           VARCHAR2(1000 BYTE),
  ITEM_DESCRIPTION                    VARCHAR2(4000 BYTE),
  REQUEST_TYPE_WO_PO                  VARCHAR2(100 BYTE),
  REQUESTED_QUANTITY                  NUMBER,
  EXPECTED_DATE                       VARCHAR2(240 BYTE),
  SHIP_TO_LOCATION                    VARCHAR2(240 BYTE),
  PROCESS_CODE                        VARCHAR2(100 BYTE),
  CUSTOMER_NAME                       VARCHAR2(500 BYTE),
  DOCUMENT_TYPE_CODE                  VARCHAR2(240 BYTE),
  CURRENCY_CODE                       VARCHAR2(240 BYTE),
  AGENT_ID                            VARCHAR2(240 BYTE),
  BILL_TO_LOCATION                    VARCHAR2(240 BYTE),
  UOM                                 VARCHAR2(20 BYTE),
  INSTRUCTIONS                        VARCHAR2(2500 BYTE),
  SHIPMENT_TYPE                       VARCHAR2(240 BYTE),
  VENDOR_CODE                         VARCHAR2(240 BYTE),
  VENDOR_SITE_CODE                    VARCHAR2(240 BYTE),
  ORACLE_PO_WO_NUMBER                 VARCHAR2(240 BYTE),
  WO_PO_INITIATED_QTY                 NUMBER,
  DELIVERED_QUANTITY                  NUMBER,
  PO_AMOUNT_AED                       NUMBER,
  PO_AMOUNT_LOCAL                     NUMBER,
  PO_WO_CREATED_DATE                  VARCHAR2(240 BYTE),
  PO_WO_EXPECTED_DELIVERY_DATE        VARCHAR2(240 BYTE),
  AMOUNT_PAID_TO_LOCAL_SUPPLIER       NUMBER,
  AMOUNT_PAID_DATE_TO_LOCAL_SUPPLIER  VARCHAR2(240 BYTE),
  PAYMENT_STATUS_TO_LOCAL_SUPPLIER    VARCHAR2(240 BYTE),
  ORACLE_STATUS                       VARCHAR2(240 BYTE),
  CREATED_BY                          VARCHAR2(240 BYTE),
  CREATED_DATE                        DATE,
  LAST_UPDATED_BY                     VARCHAR2(240 BYTE),
  LAST_UPDATED_DATE                   DATE,
  LAST_LOGIN                          VARCHAR2(240 BYTE),
  LAST_SYNC_MESSAGE                   VARCHAR2(2000 BYTE),
  LAST_SYNC_TIMESTAMP                 DATE,
  ERROR_MESSAGE                       VARCHAR2(3000 BYTE),
  STATUS                              VARCHAR2(20 BYTE),
  ATTRIBUTE1                          VARCHAR2(150 BYTE),
  ATTRIBUTE2                          VARCHAR2(150 BYTE),
  ATTRIBUTE3                          VARCHAR2(150 BYTE),
  ATTRIBUTE4                          VARCHAR2(150 BYTE),
  ATTRIBUTE5                          VARCHAR2(150 BYTE),
  ATTRIBUTE6                          VARCHAR2(150 BYTE),
  ATTRIBUTE7                          VARCHAR2(150 BYTE),
  ATTRIBUTE8                          VARCHAR2(150 BYTE),
  ATTRIBUTE9                          VARCHAR2(150 BYTE),
  ATTRIBUTE10                         VARCHAR2(150 BYTE),
  ARRTIBUTE11                         DATE,
  ATTRIBUTE12                         DATE,
  ATTRIBUTE13                         DATE,
  ATTRIBUTE14                         DATE,
  ATTRIBUTE15                         DATE,
  ATTRIBUTE16                         DATE,
  ATTRIBUTE17                         DATE,
  ATTRIBUTE18                         DATE,
  ATTRIBUTE19                         DATE,
  ATTRIBUTE20                         DATE,
  ARRTIBUTE21                         NUMBER,
  ATTRIBUTE22                         NUMBER,
  ATTRIBUTE23                         NUMBER,
  ATTRIBUTE24                         NUMBER,
  ATTRIBUTE25                         NUMBER,
  ATTRIBUTE26                         NUMBER,
  ATTRIBUTE27                         NUMBER,
  ATTRIBUTE28                         NUMBER,
  ATTRIBUTE29                         NUMBER,
  ATTRIBUTE30                         NUMBER,
  UNIT_PRICE                          NUMBER
)
/
PROMPT upgrade table XXAAC.XXAWR_PO_WO_REQUEST_STAGING
BEGIN 
ad_zd_table.upgrade('XXAAC','XXAWR_PO_WO_REQUEST_STAGING');
END;   
/
PROMPT create table XXAAC.XXAWR_PO_REQUEST_STG
CREATE TABLE XXAAC.XXAWR_PO_REQUEST_STG
(
  RECORD_ID                           NUMBER,
  OIC_INSTANCE_ID                     VARCHAR2(1000 BYTE),
  SF_PO_REQUEST_NUMBER                VARCHAR2(240 BYTE),
  SF_PO_REQUEST_ID                    VARCHAR2(240 BYTE),
  OPERATING_UNIT_NAME                 VARCHAR2(240 BYTE),
  ORG_ID                              NUMBER,
  ORGANIZATION_NAME                   VARCHAR2(240 BYTE),
  SUPPLIER_NAME                       VARCHAR2(1000 BYTE),
  ORGANIZATION_ID                     NUMBER,
  PAYMENT_TERMS                       VARCHAR2(240 BYTE),
  ITEM_CODE                           VARCHAR2(1000 BYTE),
  INVENTORY_ITEM_ID                   NUMBER,
  ITEM_DESCRIPTION                    VARCHAR2(4000 BYTE),
  UNIT_PRICE                          NUMBER,
  REQUEST_TYPE                        VARCHAR2(100 BYTE),
  PO_TYPE                             VARCHAR2(1000 BYTE),
  REQUESTED_QTY                       NUMBER,
  PO_INITIATED_QTY                    NUMBER,
  PO_RECEIVED_QTY                     NUMBER,
  PO_PENDING_QTY                      NUMBER,
  EXPECTED_DATE                       VARCHAR2(240 BYTE),
  PROCESS_CODE                        VARCHAR2(100 BYTE),
  DOCUMENT_TYPE_CODE                  VARCHAR2(240 BYTE),
  CURRENCY_CODE                       VARCHAR2(240 BYTE),
  AGENT_NAME                          VARCHAR2(240 BYTE),
  AGENT_ID                            VARCHAR2(240 BYTE),
  BILL_TO_LOCATION_ID                 NUMBER,
  SHIP_TO_LOCATION                    VARCHAR2(240 BYTE),
  SHIP_TO_LOCATION_ID                 NUMBER,
  BILL_TO_LOCATION                    VARCHAR2(240 BYTE),
  UOM                                 VARCHAR2(20 BYTE),
  INSTRUCTIONS                        VARCHAR2(2500 BYTE),
  SHIPMENT_TYPE                       VARCHAR2(240 BYTE),
  VENDOR_CODE                         VARCHAR2(240 BYTE),
  VENDOR_SITE_CODE                    VARCHAR2(240 BYTE),
  ORACLE_PO_NUMBER                    VARCHAR2(240 BYTE),
  PO_AMOUNT_AED                       NUMBER,
  PO_AMOUNT_LOCAL                     NUMBER,
  PO_WO_CREATED_DATE                  VARCHAR2(240 BYTE),
  AMOUNT_PAID_TO_LOCAL_SUPPLIER       NUMBER,
  AMOUNT_PAID_DATE_TO_LOCAL_SUPPLIER  VARCHAR2(240 BYTE),
  PAYMENT_STATUS_TO_LOCAL_SUPPLIER    VARCHAR2(240 BYTE),
  ORACLE_STATUS                       VARCHAR2(240 BYTE),
  CREATED_BY                          VARCHAR2(240 BYTE),
  CREATED_DATE                        DATE,
  LAST_UPDATED_BY                     VARCHAR2(240 BYTE),
  LAST_UPDATED_DATE                   DATE,
  LAST_LOGIN                          VARCHAR2(240 BYTE),
  LAST_SYNC_MESSAGE                   VARCHAR2(2000 BYTE),
  LAST_SYNC_TIMESTAMP                 DATE,
  ERROR_MESSAGE                       VARCHAR2(3000 BYTE),
  STATUS                              VARCHAR2(20 BYTE),
  ATTRIBUTE1                          VARCHAR2(150 BYTE),
  ATTRIBUTE2                          VARCHAR2(150 BYTE),
  ATTRIBUTE3                          VARCHAR2(150 BYTE),
  ATTRIBUTE4                          VARCHAR2(150 BYTE),
  ATTRIBUTE5                          VARCHAR2(150 BYTE),
  ATTRIBUTE6                          VARCHAR2(150 BYTE),
  ATTRIBUTE7                          VARCHAR2(150 BYTE),
  ATTRIBUTE8                          VARCHAR2(150 BYTE),
  ATTRIBUTE9                          VARCHAR2(150 BYTE),
  ATTRIBUTE10                         VARCHAR2(150 BYTE),
  ARRTIBUTE11                         DATE,
  ATTRIBUTE12                         DATE,
  ATTRIBUTE13                         DATE,
  ATTRIBUTE14                         DATE,
  ATTRIBUTE15                         DATE,
  ATTRIBUTE16                         DATE,
  ATTRIBUTE17                         DATE,
  ATTRIBUTE18                         DATE,
  ATTRIBUTE19                         DATE,
  ATTRIBUTE20                         DATE,
  ARRTIBUTE21                         NUMBER,
  ATTRIBUTE22                         NUMBER,
  ATTRIBUTE23                         NUMBER,
  ATTRIBUTE24                         NUMBER,
  ATTRIBUTE25                         NUMBER,
  ATTRIBUTE26                         NUMBER,
  ATTRIBUTE27                         NUMBER,
  ATTRIBUTE28                         NUMBER,
  ATTRIBUTE29                         NUMBER,
  ATTRIBUTE30                         NUMBER,
  MASTER_STG_ID                       NUMBER,
  RATE                                NUMBER,
  REQUESTED_DATE                      VARCHAR2(250 BYTE),
  REQUESTED_BY                        VARCHAR2(240 BYTE),
  SALES_DEMAND_TYPE                   VARCHAR2(250 BYTE),
  SALES_ORDER_NUMBER                  VARCHAR2(250 BYTE),
  SALES_ORDER_LINE_NUMBER             VARCHAR2(250 BYTE),
  ORIGINAL_REQUESTED_QTY              NUMBER
)
/
PROMPT create table APPS.XXAWR_PO_CREATION_STG
CREATE TABLE APPS.XXAWR_PO_CREATION_STG
(
  RECORD_ID                           NUMBER,
  MASTER_RECORD_ID                    NUMBER,
  OIC_INSTANCE_ID                     VARCHAR2(1000 BYTE),
  SF_PO_REQUEST_NUMBER                VARCHAR2(240 BYTE),
  SF_PO_REQUEST_ID                    VARCHAR2(240 BYTE),
  STG_HEADER_ID                       NUMBER,
  OPERATING_UNIT_NAME                 VARCHAR2(240 BYTE),
  ORG_ID                              NUMBER,
  ORGANIZATION_NAME                   VARCHAR2(240 BYTE),
  SUPPLIER_NAME                       VARCHAR2(1000 BYTE),
  SUPPLIER_ID                         NUMBER,
  ORGANIZATION_ID                     NUMBER,
  PO_TYPE                             VARCHAR2(1000 BYTE),
  EXPECTED_DATE                       VARCHAR2(240 BYTE),
  PAYMENT_TERMS                       VARCHAR2(240 BYTE),
  PROCESS_CODE                        VARCHAR2(100 BYTE),
  DOCUMENT_TYPE_CODE                  VARCHAR2(240 BYTE),
  CURRENCY_CODE                       VARCHAR2(240 BYTE),
  AGENT_NAME                          VARCHAR2(240 BYTE),
  AGENT_ID                            VARCHAR2(240 BYTE),
  SHIP_TO_LOCATION                    VARCHAR2(240 BYTE),
  SHIP_TO_LOCATION_ID                 NUMBER,
  BILL_TO_LOCATION                    VARCHAR2(240 BYTE),
  BILL_TO_LOCATION_ID                 NUMBER,
  TOTAL_QUANTITY                      NUMBER,
  INSTRUCTIONS                        VARCHAR2(2500 BYTE),
  SHIPMENT_TYPE                       VARCHAR2(240 BYTE),
  VENDOR_CODE                         VARCHAR2(240 BYTE),
  VENDOR_SITE_CODE                    VARCHAR2(240 BYTE),
  VENDOR_SITE_ID                      NUMBER,
  STG_LINE_ID                         NUMBER,
  STG_LINE_NUM                        NUMBER,
  ITEM_CODE                           VARCHAR2(1000 BYTE),
  INVENTORY_ITEM_ID                   NUMBER,
  ITEM_DESCRIPTION                    VARCHAR2(4000 BYTE),
  REQUESTED_QTY                       NUMBER,
  UNIT_PRICE                          NUMBER,
  RATE                                NUMBER,
  UOM                                 VARCHAR2(20 BYTE),
  ORACLE_PO_NUMBER                    VARCHAR2(240 BYTE),
  ORACLE_PO_HEADER_ID                 NUMBER,
  PO_INITIATED_QTY                    NUMBER,
  ORACLE_PO_LINE_ID                   NUMBER,
  ORACLE_PO_LINE_LOCATION_ID          NUMBER,
  RECEIVED_QUANTITY                   NUMBER,
  PO_AMOUNT_AED                       NUMBER,
  PO_AMOUNT_LOCAL                     NUMBER,
  PO_WO_CREATED_DATE                  VARCHAR2(240 BYTE),
  AMOUNT_PAID_TO_LOCAL_SUPPLIER       NUMBER,
  AMOUNT_PAID_DATE_TO_LOCAL_SUPPLIER  VARCHAR2(240 BYTE),
  PAYMENT_STATUS_TO_LOCAL_SUPPLIER    VARCHAR2(240 BYTE),
  ORACLE_STATUS                       VARCHAR2(240 BYTE),
  CREATED_BY                          VARCHAR2(240 BYTE),
  CREATED_DATE                        DATE,
  LAST_UPDATED_BY                     VARCHAR2(240 BYTE),
  LAST_UPDATED_DATE                   DATE,
  LAST_LOGIN                          VARCHAR2(240 BYTE),
  LAST_SYNC_MESSAGE                   VARCHAR2(2000 BYTE),
  LAST_SYNC_TIMESTAMP                 DATE,
  ERROR_MESSAGE                       VARCHAR2(3000 BYTE),
  STATUS                              VARCHAR2(20 BYTE),
  ATTRIBUTE1                          VARCHAR2(150 BYTE),
  ATTRIBUTE2                          VARCHAR2(150 BYTE),
  ATTRIBUTE3                          VARCHAR2(150 BYTE),
  ATTRIBUTE4                          VARCHAR2(150 BYTE),
  ATTRIBUTE5                          VARCHAR2(150 BYTE),
  ATTRIBUTE6                          VARCHAR2(150 BYTE),
  ATTRIBUTE7                          VARCHAR2(150 BYTE),
  ATTRIBUTE8                          VARCHAR2(150 BYTE),
  ATTRIBUTE9                          VARCHAR2(150 BYTE),
  ATTRIBUTE10                         VARCHAR2(150 BYTE),
  ARRTIBUTE11                         DATE,
  ATTRIBUTE12                         DATE,
  ATTRIBUTE13                         DATE,
  ATTRIBUTE14                         DATE,
  ATTRIBUTE15                         DATE,
  ATTRIBUTE16                         DATE,
  ATTRIBUTE17                         DATE,
  ATTRIBUTE18                         DATE,
  ATTRIBUTE19                         DATE,
  ATTRIBUTE20                         DATE,
  ARRTIBUTE21                         NUMBER,
  ATTRIBUTE22                         NUMBER,
  ATTRIBUTE23                         NUMBER,
  ATTRIBUTE24                         NUMBER,
  ATTRIBUTE25                         NUMBER,
  ATTRIBUTE26                         NUMBER,
  ATTRIBUTE27                         NUMBER,
  ATTRIBUTE28                         NUMBER,
  ATTRIBUTE29                         NUMBER,
  ATTRIBUTE30                         NUMBER,
  REQUEST_TYPE                        VARCHAR2(250 BYTE),
  MAIN_MASTER_RECORD_ID               NUMBER,
  SF_SYNC_STATUS                      VARCHAR2(20 BYTE)
)
/
PROMPT create table XXAAC.XXAWR_PO_REQUEST_DTL_TEMP
CREATE TABLE XXAAC.XXAWR_PO_REQUEST_DTL_TEMP
(
  MASTER_RECORD_ID     NUMBER,
  OIC_INSTANCE_ID      VARCHAR2(2000 BYTE),
  ITEM_CODE            VARCHAR2(1000 BYTE),
  ITEM_DESCRIPTION     VARCHAR2(2000 BYTE),
  UOM                  VARCHAR2(100 BYTE),
  SUPPLIER_NAME        VARCHAR2(2000 BYTE),
  REQUESTED_QTY        NUMBER,
  ORDERED_QTY          NUMBER,
  PENDING_QTY          NUMBER,
  UNIT_PRICE           NUMBER,
  EXPECTED_DATE        DATE,
  NOTES                VARCHAR2(4000 BYTE),
  REQUEST_NUMBER       VARCHAR2(2000 BYTE),
  REQUEST_TYPE         VARCHAR2(2000 BYTE),
  REQUESTOR_NAME       VARCHAR2(2000 BYTE),
  LAST_PURCHASE_PRICE  VARCHAR2(2000 BYTE),
  LAST_PURCHASE_DATE   DATE,
  AVG_LEAD_TIME        VARCHAR2(250 BYTE),
  AVG_PURCHASE_PRICE   NUMBER,
  PO_NUMBER            VARCHAR2(2000 BYTE),
  PO_STATUS            VARCHAR2(2000 BYTE),
  RECEIVED_QTY         NUMBER,
  PAYMENT_TERMS        VARCHAR2(2000 BYTE),
  PO_DATE              VARCHAR2(250 BYTE),
  CURRENCY             VARCHAR2(200 BYTE),
  ATTRIBUTE1           VARCHAR2(2000 BYTE),
  ATTRIBUTE2           VARCHAR2(2000 BYTE),
  ATTRIBUTE3           VARCHAR2(2000 BYTE),
  ATTRIBUTE4           VARCHAR2(2000 BYTE),
  ATTRIBUTE5           VARCHAR2(2000 BYTE),
  REQUESTED_DATE       VARCHAR2(250 BYTE)
)
/
PROMPT create table XXAAC.XXAWR_WIP_JOB_CREATION_HEADER_STG
CREATE TABLE XXAAC.XXAWR_WIP_JOB_CREATION_HEADER_STG
(
  OIC_INSTANCE_ID            NUMBER,
  RECORD_ID                  NUMBER    GENERATED ALWAYS AS IDENTITY( START WITH 1 INCREMENT BY 1),
  TYPE                       VARCHAR2(255 BYTE),
  ASSEMBLY_ITEM_CODE         VARCHAR2(255 BYTE),
  ASSEMBLY_ITEM_ID           NUMBER,
  ITEM_DESCRIPTION           VARCHAR2(4000 BYTE),
  PRIMARY_UOM_CODE           VARCHAR2(255 BYTE),
  REQUESTED_QUANTITY         NUMBER,
  WIP_QUANTITY               NUMBER,
  COMPLETED_QUANTITY         NUMBER,
  PENDING_QUANTITY           NUMBER,
  NOTES                      VARCHAR2(4000 BYTE),
  EXPECTED_DATE              DATE,
  REQUEST_TYPE               VARCHAR2(255 BYTE),
  REQUEST_NUMBER             VARCHAR2(255 BYTE),
  CUSTOMER_NAME              VARCHAR2(255 BYTE),
  SALES_ORDER_NO             VARCHAR2(255 BYTE),
  ORGANIZATION_CODE          VARCHAR2(255 BYTE),
  ORGANIZATION_ID            NUMBER,
  JOB_NUMBER                 VARCHAR2(255 BYTE),
  JOB_STATUS_TYPE            VARCHAR2(255 BYTE),
  JOB_STATUS_CODE            NUMBER,
  CLASS_CODE                 VARCHAR2(255 BYTE),
  DESCRIPTION                VARCHAR2(4000 BYTE),
  START_QUANTITY             NUMBER,
  NET_QUANTITY               NUMBER,
  FIRST_UNIT_START_DATE      VARCHAR2(255 BYTE),
  LAST_UNIT_COMPLETION_DATE  VARCHAR2(255 BYTE),
  LOAD_TYPE                  NUMBER,
  NO_OF_PERSONS              VARCHAR2(255 BYTE),
  CHANGE_OVER_TIME           VARCHAR2(255 BYTE),
  SHIFT_TIME                 VARCHAR2(255 BYTE),
  CREATED_BY                 VARCHAR2(255 BYTE),
  CREATED_BY_NAME            VARCHAR2(255 BYTE),
  CREATION_DATE              DATE,
  LAST_UPDATED_BY            VARCHAR2(255 BYTE),
  LAST_UPDATED_BY_NAME       VARCHAR2(255 BYTE),
  LAST_UPDATE_DATE           DATE,
  ERROR_MESSAGE              VARCHAR2(4000 BYTE),
  STATUS                     VARCHAR2(255 BYTE),
  WIP_ENTITY_ID              VARCHAR2(255 BYTE),
  REQUEST_DATE               DATE,
  CUSTOMER_ID                VARCHAR2(255 BYTE),
  MASTER_STG_ID              VARCHAR2(255 BYTE),
  SF_SYNC_STATUS             VARCHAR2(20 BYTE),
  SF_REQUEST_TYPE            VARCHAR2(255 BYTE),
  UNIT_OF_MEASURE            VARCHAR2(255 BYTE),
  REQUESTED_BY_NAME          VARCHAR2(255 BYTE),
  REQUESTED_BY               VARCHAR2(255 BYTE),
  ATTRIBUTE1                 VARCHAR2(255 BYTE),
  ATTRIBUTE2                 VARCHAR2(255 BYTE),
  ATTRIBUTE3                 VARCHAR2(255 BYTE),
  ATTRIBUTE4                 VARCHAR2(255 BYTE),
  ATTRIBUTE5                 VARCHAR2(255 BYTE),
  ATTRIBUTE6                 NUMBER,
  ATTRIBUTE7                 NUMBER,
  ATTRIBUTE8                 NUMBER,
  ATTRIBUTE9                 NUMBER,
  ATTRIBUTE10                NUMBER,
  ATTRIBUTE11                DATE,
  ATTRIBUTE12                DATE,
  ATTRIBUTE13                DATE,
  ATTRIBUTE14                DATE,
  ATTRIBUTE15                DATE
)
/
PROMPT upgrade table XXAAC.XXAWR_WIP_JOB_CREATION_HEADER_STG
BEGIN 
ad_zd_table.upgrade('XXAAC','XXAWR_WIP_JOB_CREATION_HEADER_STG');
END; 
/
PROMPT create table APPS.XXAWR_WIP_JOB_CREATION_LINE_STG
CREATE TABLE APPS.XXAWR_WIP_JOB_CREATION_LINE_STG
(
  OIC_INSTANCE_ID            NUMBER,
  RECORD_ID                  NUMBER      GENERATED ALWAYS AS IDENTITY( START WITH 1 INCREMENT BY 1),
  TYPE                       VARCHAR2(255 BYTE),
  ASSEMBLY_ITEM_CODE         VARCHAR2(255 BYTE),
  ASSEMBLY_ITEM_ID           NUMBER,
  ITEM_DESCRIPTION           VARCHAR2(4000 BYTE),
  PRIMARY_UOM_CODE           VARCHAR2(255 BYTE),
  REQUESTED_QUANTITY         NUMBER,
  WIP_QUANTITY               NUMBER,
  COMPLETED_QUANTITY         NUMBER,
  PENDING_QUANTITY           NUMBER,
  NOTES                      VARCHAR2(4000 BYTE),
  EXPECTED_DATE              DATE,
  REQUEST_TYPE               VARCHAR2(255 BYTE),
  REQUEST_NUMBER             VARCHAR2(255 BYTE),
  CUSTOMER_NAME              VARCHAR2(255 BYTE),
  SALES_ORDER_NO             VARCHAR2(255 BYTE),
  ORGANIZATION_CODE          VARCHAR2(255 BYTE),
  ORGANIZATION_ID            NUMBER,
  JOB_NUMBER                 VARCHAR2(255 BYTE),
  JOB_STATUS_TYPE            VARCHAR2(255 BYTE),
  JOB_STATUS_CODE            NUMBER,
  CLASS_CODE                 VARCHAR2(255 BYTE),
  DESCRIPTION                VARCHAR2(4000 BYTE),
  START_QUANTITY             NUMBER,
  NET_QUANTITY               NUMBER,
  FIRST_UNIT_START_DATE      VARCHAR2(255 BYTE),
  LAST_UNIT_COMPLETION_DATE  VARCHAR2(255 BYTE),
  LOAD_TYPE                  NUMBER,
  NO_OF_PERSONS              VARCHAR2(255 BYTE),
  CHANGE_OVER_TIME           VARCHAR2(255 BYTE),
  SHIFT_TIME                 VARCHAR2(255 BYTE),
  CREATED_BY                 VARCHAR2(255 BYTE),
  CREATED_BY_NAME            VARCHAR2(255 BYTE),
  CREATION_DATE              DATE,
  LAST_UPDATED_BY            VARCHAR2(255 BYTE),
  LAST_UPDATED_BY_NAME       VARCHAR2(255 BYTE),
  LAST_UPDATE_DATE           DATE,
  ERROR_MESSAGE              VARCHAR2(4000 BYTE),
  STATUS                     VARCHAR2(255 BYTE),
  WIP_ENTITY_ID              VARCHAR2(255 BYTE),
  REQUEST_DATE               DATE,
  CUSTOMER_ID                VARCHAR2(255 BYTE),
  MASTER_STG_ID              VARCHAR2(255 BYTE),
  SF_SYNC_STATUS             VARCHAR2(20 BYTE),
  SF_REQUEST_TYPE            VARCHAR2(255 BYTE),
  UNIT_OF_MEASURE            VARCHAR2(255 BYTE),
  REQUESTED_BY_NAME          VARCHAR2(255 BYTE),
  REQUESTED_BY               VARCHAR2(255 BYTE),
  ATTRIBUTE1                 VARCHAR2(255 BYTE),
  ATTRIBUTE2                 VARCHAR2(255 BYTE),
  ATTRIBUTE3                 VARCHAR2(255 BYTE),
  ATTRIBUTE4                 VARCHAR2(255 BYTE),
  ATTRIBUTE5                 VARCHAR2(255 BYTE),
  ATTRIBUTE6                 NUMBER,
  ATTRIBUTE7                 NUMBER,
  ATTRIBUTE8                 NUMBER,
  ATTRIBUTE9                 NUMBER,
  ATTRIBUTE10                NUMBER,
  ATTRIBUTE11                DATE,
  ATTRIBUTE12                DATE,
  ATTRIBUTE13                DATE,
  ATTRIBUTE14                DATE,
  ATTRIBUTE15                DATE
)
/
PROMPT Object APPS.AWR_PO_DETAILS_REQ_OBJ
CREATE OR REPLACE TYPE APPS."AWR_PO_DETAILS_REQ_OBJ" AS OBJECT(
ITEM_CODE VARCHAR2(1000),
ITEM_DESCRIPTION VARCHAR2(4000),
SUPPLIER_NAME VARCHAR2(2000),
SF_REQUEST_NUMBER VARCHAR2(1000),
REQUEST_TYPE VARCHAR2(1000),
PO_NUMBER VARCHAR2(1000),
PO_STATUS VARCHAR2(100),
RECEIVED_QTY NUMBER,
PAYMENT_TERMS VARCHAR2(500),
PO_DATE VARCHAR2(250),
CURRENCY VARCHAR2(100),
REQUESTED_QTY NUMBER,
CREATED_BY VARCHAR2(250),
CREATION_DATE  VARCHAR2(250)
)
/
PROMPT Create type APPS.AWR_PO_DETAILS_REQ_TYPE
CREATE OR REPLACE TYPE APPS."AWR_PO_DETAILS_REQ_TYPE" IS TABLE OF AWR_PO_DETAILS_REQ_OBJ
/
PROMPT SEQUENCE XXAAC.PO_STG_RECORD_SEQ 
CREATE SEQUENCE XXAAC.PO_STG_RECORD_SEQ
start with 1001
increment by 1
nocycle
nocache
/ 
PROMPT SEQUENCE XXAAC.PO_STG_HEADER_SEQ 
CREATE SEQUENCE XXAAC.PO_STG_HEADER_SEQ
start with 1001
increment by 1
nocycle
nocache
/ 
PROMPT SEQUENCE XXAAC.PO_STG_LINE_SEQ 
CREATE SEQUENCE XXAAC.PO_STG_LINE_SEQ
start with 1001
increment by 1
nocycle
nocache
/
PROMPT SEQUENCE XXAAC.XXAWR_WO_REQUEST_NUMBER_SEQ
CREATE SEQUENCE XXAAC.XXAWR_WO_REQUEST_NUMBER_SEQ
START WITH 10000
INCREMENT BY 1
nocycle
nocache
/
SHOW ERROR; 
EXIT;