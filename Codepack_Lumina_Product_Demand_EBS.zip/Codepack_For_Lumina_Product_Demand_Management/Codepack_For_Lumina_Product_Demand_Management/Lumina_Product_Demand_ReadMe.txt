/************************************************************
*    	Object Deployment Readme
************************************************************
************************************************************/


1) Move all files inside "Codepack_For_Lumina_Product_Demand_Management" Directory for Production Migration Scripts to application Server with privilege of (755) for all files.

2) Open document "BR100_Lumina_Product_demand_DFF_setup.docx" and perform the configuration for DFF setup. Note: Only setup DFF part, no need to setup Lookup.
 
3) creating AOL Objects in EBS

  3.1) Navigate to "/aol_objects" directory.
  3.2) Execute XXAWR_PRODUCT_DEMAND_AOL_DEPLOY.sh script file.
  3.3) Provide to necessary credentials to proceed execution of script.

4) Creating Database Objects in EBS

  4.1) Navigate to "/database_object" directory.
  4.2) Execute DB_Deploy.sh script file.
  4.3) Provide the apps Schema and XXAAC schema credentials to run the script.
  
  
