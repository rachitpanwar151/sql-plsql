----------Codepack Execution Details 
/*

             Owner        - DBA

             Server       - Production UNIX Server

             Directory    - $HOME

             Permissiions - 0775

---------------------------------*/

AOL Object Migration	--For DBA
Step 1: Move AOL_Objects folder to unix server.
Step 2: Open the Codepack for AOL Objects folder.
Step 3: Give read,write and execute permission to codepack folder and files.
Step 4: Execute the script AOL_Deploy.sh using PuTTY.

DB Object Migration		--For DBA
Step 1: Move Database_Objects folder to unix server.
Step 2: Open the Codepack for Database Objects folder.
Step 3: Give read,write and execute permission to codepack folder and files.
Step 4: Execute the script DB_Deploy.sh using PuTTY. 

Configuration --Application Support Team
step 1:Upon successful completion of Database_Objects Migration, update value sets for "Industry" and "Customer Type".
Follow the steps of 
"BR100_GIT22PRJ068_Lumina_Dff_Configuration_setup-Indusrty and Customer_Type value set" document.
Step 2:Upon successful completion of AOL_Objects Migration, Perform configuration as per 
document - BR100_GIT22PRJ068_Lumina_Dff_Configuration_setup.

Note : In case of any failures, please reach out to akash.talan@intelloger.com.