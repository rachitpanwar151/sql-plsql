# !/bin/bash
# ====================================================================
#                        AW Rostamani   	                       
#                           Dubai	                                
# ====================================================================
# $Header:$                                                          
# Description      : Deployment Script                                
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0     07-SEP-2023  S Suresh - OSI     Initial Draft              
# ==================================================================== 
APPS_LOGIN_ID="$1"
XX_LOGIN_ID="$2"
TS_NAME="$3"
IDX_NAME="$4"
CUSTOM_TOP="$5"

# +======================================================================+
#  Function to Check the validity of loginids and passwords.
# +======================================================================+
CHKLOGIN(){
    if sqlplus /nolog <<! >/dev/null 2>&1
          WHENEVER SQLERROR EXIT 1;
          CONNECT $1 ;
          EXIT;
!
     then
          echo OK
     else
          echo NOK
     fi
}

#
# +======================================================================+
#  Function to Check the existance of table space and index space
# +======================================================================+
CHKTABCRE(){
    if sqlplus -s /nolog <<! >/dev/null 2>&1
        WHENEVER SQLERROR EXIT 1;
        CONNECT $1 ;
    -- 
    ECHO "BEFORE CHECKING"
    
    Declare
     l_temp  char(1);
    Begin
     SELECT 'X'
     INTO   l_temp
     FROM   USER_TABLESPACES
     WHERE  TABLESPACE_NAME = UPPER('$2')
     AND    ROWNUM = 1;

    END;
/

       EXIT;
!
    then
        echo OK
    else
        echo NOK
    fi
}

# *******************************************************************	   
#  Ask if the user wants to proceed or not	   
# *******************************************************************	   
while [ "$PROCEED_YN" = "" -o "$PROCEED_YN" = "n" ]	   
do	   
	   
     if [ "$PROCEED_YN" = "n"  -o "$PROCEED_YN" = "N" ];then	   
            echo "Exiting Installation Process... \n"	   
            exit 0	   
     fi	   
     if [ "$PROCEED_YN" = "" ];then	   
            echo "Would you like Start the Installation...Press [y/n]  in Lower Case  to Continue: "	   
            read PROCEED_YN	   
            if [ "$PROCEED_YN" != "y" -a "$PROCEED_YN" != "n" ];then	   
               echo "Please enter y/n [Case Sensitive] \c"	   
               PROCEED_YN=""	   
            fi	   
     fi	   
done	   
# *******************************************************************
#  Inital messages
# *******************************************************************
echo ""
echo "+------------------------------------------------------------------+" 
echo "Code pack installation.... " 
echo "Please review all the log files created by this installation program" 
echo "+------------------------------------------------------------------+"  	
echo ""
# *******************************************************************
#  Check if APPS Login Id is entered else prompt to get it
# *******************************************************************
while [ "$APPS_LOGIN_ID" = "" -o `CHKLOGIN "$APPS_LOGIN_ID" "DUAL"` = "NOK" ]
do
    if [ "$APPS_LOGIN_ID" = "" ];then
        echo "Enter APPS Userid/Passwd :"
        read APPS_LOGIN_ID
        #if [ "$APPS_LOGIN_ID" = "" ];then
        #    APPS_LOGIN_ID="apps/apps" 
        #fi 
    else
        echo "Please re-enter APPS Userid/Passwd :  "
        read APPS_LOGIN_ID
    fi
done

APPS_LOGIN=`echo $APPS_LOGIN_ID | cut -d"/" -f1`
APPS_PWD=`echo $APPS_LOGIN_ID | cut -d"/" -f2`
# **********************************************************************
#  Check if Custom Application Login Id is entered else prompt to get it
# **********************************************************************
while [ "$XX_LOGIN_ID" = "" -o `CHKLOGIN "$XX_LOGIN_ID" "DUAL"` = "NOK" ]
do
    if [ "$XX_LOGIN_ID" = "" ];then
        echo "Enter Custom schema Userid/Passwd :  " 
        read XX_LOGIN_ID
    else
        echo "Please re-enter Custom Userid/Passwd :  "
        read XX_LOGIN_ID
    fi
done

XX_LOGIN=`echo $XX_LOGIN_ID | cut -d"/" -f1`
XX_PWD=`echo $XX_LOGIN_ID | cut -d"/" -f2`

# ******************************************************************
#  Check if data tablespace name is entered else prompt to get it
# ******************************************************************
#while [ "$TS_NAME" = "" -o `CHKTABCRE "$XX_LOGIN_ID" "$TS_NAME"` = "NOK" ]
#do
#if [ "$TS_NAME" = "" ];then
#        echo "Enter Data Tablespace Name:  " 
#        read TS_NAME
#    else
#       echo "Please re-enter Data Tablespace Name :  "
#        read TS_NAME
#    fi
#done
# ******************************************************************
#  Check if Index tablespace name is entered else prompt to get it
# ******************************************************************
#while [ "$IDX_NAME" = "" -o `CHKTABCRE "$XX_LOGIN_ID" "$TS_NAME"` = "NOK" ]
#do
#if [ "$IDX_NAME" = "" ];then
#        echo "Enter Index Tablespace Name:  " 
#        read IDX_NAME
#    else
#        echo "Please re-enter Index Tablespace Name :  "
#        read IDX_NAME
#    fi
#done
#-------------------------------------------------------------------
# The handle_error function will report error and exit if there
# is an error while copying.
#-------------------------------------------------------------------
mcp()
{
  cp $1 $2
  if [ $? = 0 ]
  then
    echo "Copied $1 to $2"
  else
    echo "Copy process of $1 to $2 failed!! Exiting installation process...."
    exit 2
  fi
}

TS_NAME='XXAAC_TS_DATA'
IDX_NAME='XXAAC_TS_IDX'
CUSTOM_TOP=$XXAAC_TOP
export APPS_LOGIN
export APPS_PWD
export XX_LOGIN
export XX_PWD
export TS_NAME
export IDX_NAME
export CUSTOM_TOP

echo "Table space Name "$TS_NAME
echo "INdex Space Name "$IDX_NAME

#---------------------------------------------------------------------
#  Copy .SQL,.PKS,.PKB
#---------------------------------------------------------------------
echo "Copying the various install files to the appropriate folders ..."
echo "Copying the variables  "

mcp XXAWR_ACCOUNT_TABLE_OBJECTS_SCRIPT.sql        	    $CUSTOM_TOP/admin/sql/XXAWR_ACCOUNT_TABLE_OBJECTS_SCRIPT.sql
mcp XXAWR_AR_SF_CUST_ACCOUNT_PKG.pks                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ACCOUNT_PKG.pks
mcp XXAWR_AR_SF_CUST_ACCOUNT_PKG.pkb                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ACCOUNT_PKG.pkb
mcp XXAWR_AR_SF_CUST_ADDRESS_PKG.pks                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ADDRESS_PKG.pks
mcp XXAWR_AR_SF_CUST_ADDRESS_PKG.pkb                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ADDRESS_PKG.pkb
mcp XXAWR_AR_SF_CUST_CONTACT_PKG.pks                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CONTACT_PKG.pks
mcp XXAWR_AR_SF_CUST_CONTACT_PKG.pkb                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CONTACT_PKG.pkb
mcp XXAWR_AR_SF_CUST_CREDIT_INFO.pks                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CREDIT_INFO.pks
mcp XXAWR_AR_SF_CUST_CREDIT_INFO.pkb                        $CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CREDIT_INFO.pkb

echo " "
echo "Finished copying successfully the various install files to the appropriate folders."
echo " "

echo "-------------------------------------------------------------------------------"
echo "Creating Tables and Related Objects..................................................."
echo "-------------------------------------------------------------------------------" 
echo  "Currently Executing Script - XXAWR_ACCOUNT_TABLE_OBJECTS_SCRIPT.sql"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_ACCOUNT_TABLE_OBJECTS_SCRIPT.sql        $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo "-------------------------------------------------------------------------------"
echo "Installing Package Specs......................................................."
echo "-------------------------------------------------------------------------------"  

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_ACCOUNT_PKG.pks"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ACCOUNT_PKG.pks               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_ADDRESS_PKG.pks"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ADDRESS_PKG.pks               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_CONTACT_PKG.pks"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CONTACT_PKG.pks               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_CREDIT_INFO.pks"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CREDIT_INFO.pks               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME


echo "-------------------------------------------------------------------------------"
echo "Installing Package Bodies......................................................"
echo "-------------------------------------------------------------------------------" 

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_ACCOUNT_PKG.pkb"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ACCOUNT_PKG.pkb               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_ADDRESS_PKG.pkb"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_ADDRESS_PKG.pkb               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_CONTACT_PKG.pkb"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CONTACT_PKG.pkb               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

echo  "Currently Executing Script - XXAWR_AR_SF_CUST_CREDIT_INFO.pkb"
sqlplus $APPS_LOGIN/$APPS_PWD @$CUSTOM_TOP/admin/sql/XXAWR_AR_SF_CUST_CREDIT_INFO.pkb               $APPS_LOGIN $APPS_PWD  $XX_LOGIN $XX_PWD $TS_NAME $IDX_NAME

 
echo "*******************END OF INSTALLATION*******************"
exit 0

