/*# !/bin/bash
# ====================================================================
#                        AW Rostamani                              
#                           Dubai                                   
# ====================================================================
# $Header:$                                                          
# Description      : Script to create BOM Staging tables in APPS Schema   
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0      7-03-24      Intelloger         Initial Draft              
# ==================================================================== 
*/
--WHENEVER SQLERROR CONTINUE;
SET HEADING OFF
SET TERM ON
SET SHOW OFF
SET VERIFY OFF
rem ******************************************************
rem  Accepting the appropriate variables to the arguments*
rem ******************************************************
COLUMN appsuser    NEW_VALUE APPS_LOGIN        NOPRINT
COLUMN appspwd     NEW_VALUE APPS_PWD          NOPRINT 
COLUMN xxaacuser   NEW_VALUE XXAAC_LOGIN       NOPRINT
COLUMN xxaacpwd    NEW_VALUE XXAAC_PWD         NOPRINT 
COLUMN tsname      NEW_VALUE TS_NAME           NOPRINT
COLUMN idxname     NEW_VALUE IDX_NAME          NOPRINT 
SELECT '&&1' appsuser 
     ,'&&2' appspwd
     ,'&&3' xxaacuser
     ,'&&4' xxaacpwd
     ,'&&5' tsname
     ,'&&6' idxname
FROM   dual
/
-----------------------------------------------------------
PROMPT connecting apps for tables, sequence and synonym.
-----------------------------------------------------------
conn &1/&2
/
PROMPT create table XXAAC.XXAWR_BOM_EXPORT_STG
CREATE TABLE XXAAC.XXAWR_BOM_EXPORT_STG
(
  EXTERNAL_ORACLE_ID          VARCHAR2(1000 BYTE),
  ORGANIZATION_ID             NUMBER,
  ASSEMBLY_ITEM_ID            NUMBER,
  ASSEMBLY_ITEM_CODE          VARCHAR2(40 BYTE),
  SF_PARENT_PRODUCT_ID        VARCHAR2(50 BYTE),
  ASSEMBLY_ITEM_DESCRIPTION   VARCHAR2(240 BYTE),
  ASSEMBLY_TYPE               NUMBER,
  PRIMARY_UOM_CODE            VARCHAR2(20 BYTE),
  IMPLEMENTATION_DATE         DATE,
  SF_PRODUCT_ID               VARCHAR2(50 BYTE),
  COMPONENT_ITEM_ID           NUMBER,
  COMPONENT_SEQUENCE_ID       NUMBER,
  COMPONENT_ITEM_CODE         VARCHAR2(40 BYTE),
  COMPONENT_COST              NUMBER,
  INVENTORY_ITEM_STATUS_CODE  VARCHAR2(10 BYTE),
  ITEM_SEQUENCE               NUMBER,
  OPERATION_SEQ_NUM           NUMBER,
  COMPONENT_QUANTITY          NUMBER,
  COMPONENT_EFFECTIVITY_DATE  DATE,
  DISABLE_DATE                DATE,
  LAST_RUN_DATE               DATE,
  CREATED_BY                  NUMBER,
  CREATION_DATE               DATE,
  LAST_UPDATE_BY              NUMBER,
  LAST_UPDATE_DATE            DATE,
  LOGIN_ID                    NUMBER,
  STATUS                      VARCHAR2(1 BYTE),
  SF_SYNC_FLAG                VARCHAR2(3 BYTE),
  LAST_SYNC_MESSAGE           VARCHAR2(3000 BYTE),
  LAST_SYNC_TIMESTAMP         DATE,
  REQUEST_ID                  NUMBER
)
/

PROMPT upgrade table XXAWR_BOM_EXPORT_STG
BEGIN
 ad_zd_table.upgrade('XXAAC','XXAWR_BOM_EXPORT_STG');
END; 
/

PROMPT create VIEW XXAWR_BOM_EXPORT_STG
CREATE OR REPLACE VIEW XXAWR_BOM_EXPORT_STG_V as 
select * from XXAAC.XXAWR_BOM_EXPORT_STG
/

PROMPT create table XXAAC.XXAWR_BOM_SUB_EXPORT_STG
CREATE TABLE XXAAC.XXAWR_BOM_SUB_EXPORT_STG
(
  EXTERNAL_ORACLE_ID       VARCHAR2(1000 BYTE),
  EXTERNAL_ORACLE_LINE_ID  VARCHAR2(1000 BYTE),
  ASSEMBLY_ID              NUMBER,
  ORGANIZATION_ID          NUMBER,
  COMPONENT_ITEM_ID        NUMBER,
  COMPONENT_SEQUENCE_ID    NUMBER,
  SUBSTITUTE_COMPONENT_ID  NUMBER,
  SF_PRODUCT_ID_FOR_SUB    VARCHAR2(150 BYTE),
  SUB_COMP_ITEM_ID         NUMBER,
  SUB_COMP_ITEM_CODE       VARCHAR2(150 BYTE),
  SUB_COMP_UOM             VARCHAR2(30 BYTE),
  SUB_COMP_QUANTITY        NUMBER,
  LAST_RUN_DATE            DATE,
  CREATED_BY               NUMBER,
  CREATION_DATE            DATE,
  LAST_UPDATED_BY          NUMBER,
  LAST_UPDATE_DATE         DATE,
  LOGIN_ID                 NUMBER,
  REQUEST_ID               NUMBER,
  STATUS                   VARCHAR2(3 BYTE)
)
/

PROMPT upgrade table XXAWR_BOM_SUB_EXPORT_STG
BEGIN
 ad_zd_table.upgrade('XXAAC','XXAWR_BOM_SUB_EXPORT_STG');
END; 
/

PROMPT create VIEW XXAWR_BOM_SUB_EXPORT_STG
CREATE OR REPLACE VIEW XXAWR_BOM_SUB_EXPORT_STG_V as 
select * from XXAAC.XXAWR_BOM_SUB_EXPORT_STG
/

SHOW ERROR; 
EXIT;