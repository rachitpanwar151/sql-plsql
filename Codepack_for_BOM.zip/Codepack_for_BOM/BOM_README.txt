
----------Codepack Execution Details
/*
             Owner        - DBA
             Server       - Production UNIX Server
             Directory    - $HOME
             Permissiions - 0775
---------------------------------*/

DB Object Migration		--For DBA

Step 1: Move migration codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Open the Codepack_for_BOM folder then navigate "/Database_Objects" folder.
Step 4: Execute the script DB_Deploy.sh using PuTTY.

AOL Objects Migration		--For DBA

Step 1: Open the Codepack_for_BOM folder then navigate "/AOL_Objects" folder.
Step 2: Execute the script XXAWR_INV_BOM_EXP.sh using PuTTY.

Configuration --Application Support Team


Step 1: Upon successful completion of DB Objects and AOL Object Migration, access the Oracle application.
	Then:
	Navigation ----> System Administrator >> Security >> Responsibility>> Request
Step 2: Query the form and Enter the below details:
         Request Group - BOM reports
         Application   - Bills of Material
	 Code 	       - CST_BOM_REPORTS
Step 3: Click on child records and click on '+'.
Step 4: Enter Concurrent Program Name - "AWRL BOM EXPORT TO SF" 
	Then Save it.
Step 5: After this navigate to the "Bills of Material" Responsibility and submit the concurrent Program 
       "AWRL BOM EXPORT TO SF" and schedule this concurrent program Periodically for every 3 Hours. 
Step 6: Apply the Interval as "From the completion of the Prior Run" and Save this Schedule.
Step 7: Submit the Concurrent Program.

Note : During Go-Live Activity User can check Cutover Date in the Lookup for Lookup Type "BOM" and
	can change as per Business Need.

In case of any failures, please reach out to santosh.tiwary@intelloger.com.
