/*# !/bin/bash
# ====================================================================
#                        AW Rostamani                              
#                           Dubai                                   
# ====================================================================
# $Header:$                                                          
# Description      : Script to create SO Staging tables in APPS Schema   
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0      7-03-24      Intelloger         Initial Draft              
# ==================================================================== 
*/
--WHENEVER SQLERROR CONTINUE;
SET HEADING OFF
SET TERM ON
SET SHOW OFF
SET VERIFY OFF
rem ******************************************************
rem  Accepting the appropriate variables to the arguments*
rem ******************************************************
COLUMN appsuser    NEW_VALUE APPS_LOGIN        NOPRINT
COLUMN appspwd     NEW_VALUE APPS_PWD          NOPRINT 
COLUMN xxaacuser   NEW_VALUE XXAAC_LOGIN       NOPRINT
COLUMN xxaacpwd    NEW_VALUE XXAAC_PWD         NOPRINT 
COLUMN tsname      NEW_VALUE TS_NAME           NOPRINT
COLUMN idxname     NEW_VALUE IDX_NAME          NOPRINT 
SELECT '&&1' appsuser 
     ,'&&2' appspwd
     ,'&&3' xxaacuser
     ,'&&4' xxaacpwd
     ,'&&5' tsname
     ,'&&6' idxname
FROM   dual
/
-----------------------------------------------------------
PROMPT connecting apps for tables, sequence and synonym.
-----------------------------------------------------------
conn &1/&2
/
DROP TABLE XXAAC.XXAWR_SO_STATUS_UPD_STG CASCADE CONSTRAINTS;

CREATE TABLE XXAAC.XXAWR_SO_STATUS_UPD_STG
(
  RECORD_ID                   NUMBER    generated always as identity(start with 1 increment by 1),
  ORACLE_DEL_REF_ID           VARCHAR2(150 BYTE),
  ORACLE_LINE_REF_ID          VARCHAR2(150 BYTE),
  ORACLE_HEADER_REF_ID        VARCHAR2(150 BYTE),
  SF_ORDER_ID                 VARCHAR2(150 BYTE),
  SF_LINE_ID                  VARCHAR2(150 BYTE),
  STG_DEL_INSTR_ID            VARCHAR2(150 BYTE),
  OIC_INSTANCE_ID             VARCHAR2(150 BYTE),
  ORG_ID                      NUMBER,
  HEADER_ID                   VARCHAR2(40 BYTE),
  LINE_ID                     NUMBER,
  ORDER_NUMBER                NUMBER,
  ORDER_TYPE                  VARCHAR2(300 BYTE),
  LINE_NUMBER                 NUMBER,
  ORDER_LINE_STATUS           VARCHAR2(30 BYTE),
  DELIVERY_ID                 NUMBER,
  ORDER_LINE_DELIVERY_STATUS  VARCHAR2(500 BYTE),
  ORDERED_QUANTITY            NUMBER,
  SHIPPED_QUANTITY            NUMBER,
  LOT_NUMBER                  VARCHAR2(80 BYTE),
  HOLD_NAME                   VARCHAR2(240 BYTE),
  PROCESS_FLAG                VARCHAR2(1 BYTE),
  CREATION_DATE               DATE,
  CREATED_BY                  NUMBER,
  LAST_UPDATE_DATE            DATE,
  LAST_UPDATED_BY             NUMBER,
  LAST_UPDATE_LOGIN           NUMBER,
  SALES_INVOICE_PRINT_FLAG    VARCHAR2(3 BYTE),
  DELIVERY_NOTES_PRINT_FLAG   VARCHAR2(3 BYTE),
  ATTRIBUTE1                  VARCHAR2(150 BYTE),
  ATTRIBUTE2                  VARCHAR2(150 BYTE),
  ATTRIBUTE3                  VARCHAR2(150 BYTE),
  ATTRIBUTE4                  VARCHAR2(150 BYTE),
  ATTRIBUTE5                  VARCHAR2(150 BYTE),
  ATTRIBUTE6                  VARCHAR2(150 BYTE),
  ATTRIBUTE7                  VARCHAR2(150 BYTE),
  ATTRIBUTE8                  VARCHAR2(150 BYTE),
  ATTRIBUTE9                  VARCHAR2(150 BYTE),
  ATTRIBUTE10                 VARCHAR2(150 BYTE),
  ERR_MSG                     VARCHAR2(1500 BYTE),
  TAX_VALUE                   NUMBER,
  TAX_CODE                    VARCHAR2(50 BYTE)
)
/

PROMPT upgrade table XXAWR_SO_STATUS_UPD_STG
BEGIN
 ad_zd_table.upgrade('XXAAC','XXAWR_SO_STATUS_UPD_STG');
END;
/

SHOW ERROR; 
EXIT;