###################################################################################################
# $ID: Install.sh
# ORIGINAL AUTHOR     : Vivek Uniyal
# MODULE TYPE         : SHELL SCRIPT
# DESCRIPTION         : PURPOSE OF THIS SHELL SCRIPT IS TO INSTALL ALL THE FILES IN APPS schema.
# MODIFICATION HISTORY
# -----------------------------------------------------------------------------------------------
# VERSION NAME               		DATE         DESCRIPTION OF CHANGE
# ------- ------------------ 		-----------  -------------------------------------------------------
# 1.0     Vivek Uniyal                07-MAR-2024  INITIAL CREATION.
###################################################################################################
echo "$HOME_PATH"
LOG_FILE=INSTALL_LOG_"$DATE_TIME".log
echo
echo "***Current Date and Time****" > $LOG_FILE
echo $DATE_TIME >> $LOG_FILE
echo "----------------------------" >> $LOG_FILE
echo >> $LOG_FILE

echo "Installing INSTALL.sh for Install"

echo "Enter the APPS Schema User Password \c"
stty -echo
read P_APPS_PASSWD
stty echo

echo "Enter the Host name \c"
read HOST_NAME

echo "Enter the Port \c"
read PORT

echo "Enter the SID \c"
read SID


# --------------------------------------------------------------------
#  Function to Check the validity of login ids and password.
# --------------------------------------------------------------------
CHKLOGIN(){
     if sqlplus -s /nolog <<! >/dev/null 2>&1
          WHENEVER SQLERROR EXIT 1;
          CONNECT $1 ;
          EXIT;
!
    then
        echo OK
    else
        echo NOK
    fi
}

# --------------------------
#  Prompt for APPS Password
# --------------------------
while [ "apps/$P_APPS_PASSWD" = "" -o `CHKLOGIN "apps/$P_APPS_PASSWD"` = "NOK" ]
do
    if [ "$P_APPS_PASSWD" = "" ];then
            echo "Please enter password for $apps_user : "
            read P_APPS_PASSWD
    else
        echo "$apps_user password incorrect"
        P_APPS_PASSWD=""
    fi
done
ls -ltr
echo 'Setting Permissions..'
chmod 755 XX*


#- Lookup 
echo "Registering AOL Objects with FNDLOAD ..."
echo "1 Lookup installing "
echo "Current file XXAWR_SF_OIC_LUM_INTG_LKP.ldt "
FNDLOAD apps/$apps_pwd O Y UPLOAD $FND_TOP/patch/115/import/aflvmlu.lct XXAWR_SF_OIC_LUM_INTG_LKP.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE

#- Alert 
echo "Registering AOL Objects with FNDLOAD ..."
echo "3 Alert installing "
echo "Current file XXAWR_RMA_DELVY_STATUS_UPD_ALR.ldt "
FNDLOAD apps/$apps_pwd O Y UPLOAD $ALR_TOP/patch/115/import/alr.lct XXAWR_RMA_DELVY_STATUS_UPD_ALR.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
echo "Current file XXAWR_SO_DELVY_STATUS_UPD_ALR.ldt "
FNDLOAD apps/$apps_pwd O Y UPLOAD $ALR_TOP/patch/115/import/alr.lct XXAWR_SO_DELVY_STATUS_UPD_ALR.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
echo "Shell Script Execution done!"
FNDLOAD apps/$apps_pwd O Y UPLOAD $ALR_TOP/patch/115/import/alr.lct XXAWR_HLD_DELVY_STATUS_UPD_ALR.ldt UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE
echo "Shell Script Execution done!"
echo ""
echo "*******************END OF INSTALLATION*******************"
exit 0
 