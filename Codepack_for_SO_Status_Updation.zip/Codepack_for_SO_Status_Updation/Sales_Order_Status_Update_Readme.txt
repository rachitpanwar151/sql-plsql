

----------Codepack Execution Details
/*
             Owner        - DBA
             Server       - Production UNIX Server
             Directory    - $HOME
             Permissiions - 0775
---------------------------------*/


DB Object Migration		--For DBA

Step 1: Move migration codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Open the Codepack_for_SO_Status_Updation folder then navigate "/Database_Objects" folder.
Step 4: Execute the script DB_Deploy.sh using PuTTY.

AOL Objects Migration		--For DBA

Step 1: Open the Codepack_for_SO_Status_Updation folder then navigate "/AOL_Objects" folder.
Step 2: Execute the script XXAWR_SF_SO_AOL.sh using PuTTY.

Business Event Objects Configuration		--For DBA

Step 1 : Configure Business Event according as provided "BR100_Lumina_Business_event_Sales_order_update" 
	Document.


In case of any failures, please reach out to santosh.tiwary@intelloger.com.
