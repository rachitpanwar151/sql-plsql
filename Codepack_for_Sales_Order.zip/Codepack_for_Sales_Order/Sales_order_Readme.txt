----------Codepack Execution Details
/*
             Owner        - DBA
             Server       - Production UNIX Server
             Directory    - $HOME
             Permissiions - 0775
---------------------------------*/





Database_Objects Migration		--For DBA


Step 1: Move Database_Objects codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Execute the script DB_Deploy.sh using PuTTY.

Wait for the file to be execute successful completion.


AOL_Objects Migration		--For DBA

Step 1: Move AOL_Objects codepack folder to unix server.
Step 2: Give read,write and execute permission to codepack folder and files.
Step 3: Execute the script XXAWR_SF_SO_AOL.sh using PuTTY.


Configuration --Application Support Team

Step 1: Upon successful completion of DB Object Migration, access the Oracle application. 
        
Navigate to the System Administrator responsibility and allocate "XXAWRL SF OIC Sales Order Creation Process" to the
Group "OM Concurrent Programs"  and application "Order Management" responsibility.
      
	  Navigate------->system adminstrator >>responsibility>>request group
  		a) Query the form and enter below details:
        b) Request Group - OM Concurrent Programs
        c) Application - Order Management
        d) Click on child records and click on '+'
        e) Enter program name - "XXAWRL SF OIC Sales Order Creation Process"
        f) Save


In case of any failures, please reach out to rachit.panwar@intelloger.com.
