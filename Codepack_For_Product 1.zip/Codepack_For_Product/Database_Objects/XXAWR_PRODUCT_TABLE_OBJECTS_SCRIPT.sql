/*# !/bin/bash
# ====================================================================
#                        AW Rostamani                              
#                           Dubai                                   
# ====================================================================
# $Header:$                                                          
# Description      : Script to create backup tables in XXAAC Schema   
# Change History:                                                      
# ---------------                                                     
# Version  Date         Author             Remarks                    
# -------  -----------  --------------     --------------------------- 
#  1.0      7-03-24      Intelloger                   Initial Draft              
# ==================================================================== 
*/
--WHENEVER SQLERROR CONTINUE;
SET HEADING OFF
SET TERM ON
SET SHOW OFF
SET VERIFY OFF
rem ******************************************************
rem  Accepting the appropriate variables to the arguments*
rem ******************************************************
COLUMN appsuser    NEW_VALUE APPS_LOGIN        NOPRINT
COLUMN appspwd     NEW_VALUE APPS_PWD          NOPRINT 
COLUMN xxaacuser   NEW_VALUE XXAAC_LOGIN       NOPRINT
COLUMN xxaacpwd    NEW_VALUE XXAAC_PWD         NOPRINT 
COLUMN tsname      NEW_VALUE TS_NAME           NOPRINT
COLUMN idxname     NEW_VALUE IDX_NAME          NOPRINT 
SELECT '&&1' appsuser 
     ,'&&2' appspwd
     ,'&&3' xxaacuser
     ,'&&4' xxaacpwd
     ,'&&5' tsname
     ,'&&6' idxname
FROM   dual
/
-----------------------------------------------------------
PROMPT connecting apps for tables, sequence and synonym.
-----------------------------------------------------------
conn &1/&2
/
PROMPT create table APPS.XXAWR_PRODUCT_STG
CREATE TABLE "APPS"."XXAWR_PRODUCT_STG"
(
  OIC_INSTANCE_ID             NUMBER,
  RECORD_ID                   NUMBER            GENERATED ALWAYS AS IDENTITY,
  ITEM_CODE                   VARCHAR2(40 BYTE),
  ITEM_DESCRIPTION            VARCHAR2(240 BYTE),
  ORGANIZATION_CODE           VARCHAR2(50 BYTE),
  PRIMARY_UOM_CODE            VARCHAR2(25 BYTE),
  START_DATE_ACTIVE           DATE,
  END_DATE_ACTIVE             DATE,
  ITEM_TYPE                   VARCHAR2(30 BYTE),
  INVENTORY_ITEM_FLAG         VARCHAR2(1 BYTE),
  PLANNING_MAKE_BUY_CODE      NUMBER,
  CATEGORY_SET_NAME           VARCHAR2(30 BYTE),
  CATEGORY                    VARCHAR2(327 BYTE),
  BRAND                       VARCHAR2(100 BYTE),
  PRODUCT_CATEGORY            VARCHAR2(100 BYTE),
  PRODUCT_FAMILY              VARCHAR2(100 BYTE),
  COMP_CATEGORY               VARCHAR2(100 BYTE),
  COMP_MAIN_CATEGORY          VARCHAR2(100 BYTE),
  INVENTORY_ITEM_ID           NUMBER,
  ORGANIZATION_ID             NUMBER,
  TEMPLATE_NAME               VARCHAR2(30 BYTE),
  CREATED_BY                  NUMBER,
  CREATION_DATE               DATE,
  LAST_UPDATED_BY             NUMBER,
  LAST_UPDATE_DATE            DATE,
  LAST_UPDATE_LOGIN           NUMBER,
  STATUS                      VARCHAR2(10 BYTE),
  ERROR_MSG                   VARCHAR2(1000 BYTE),
  ATTRIBUTE_CATEGORY          VARCHAR2(240 BYTE),
  ATTRIBUTE1                  VARCHAR2(240 BYTE),
  ATTRIBUTE2                  VARCHAR2(240 BYTE),
  ATTRIBUTE3                  VARCHAR2(240 BYTE),
  ATTRIBUTE4                  VARCHAR2(240 BYTE),
  ATTRIBUTE5                  VARCHAR2(240 BYTE),
  ATTRIBUTE6                  VARCHAR2(240 BYTE),
  ATTRIBUTE7                  VARCHAR2(240 BYTE),
  ATTRIBUTE8                  VARCHAR2(240 BYTE),
  ATTRIBUTE9                  VARCHAR2(240 BYTE),
  ATTRIBUTE10                 VARCHAR2(240 BYTE),
  ATTRIBUTE11                 VARCHAR2(240 BYTE),
  ATTRIBUTE12                 VARCHAR2(240 BYTE),
  ATTRIBUTE13                 VARCHAR2(240 BYTE),
  ATTRIBUTE14                 VARCHAR2(240 BYTE),
  ATTRIBUTE15                 VARCHAR2(240 BYTE),
  NUMBER_ATTRIBUTE1           NUMBER,
  NUMBER_ATTRIBUTE2           NUMBER,
  NUMBER_ATTRIBUTE3           NUMBER,
  NUMBER_ATTRIBUTE4           NUMBER,
  NUMBER_ATTRIBUTE5           NUMBER,
  NUMBER_ATTRIBUTE6           NUMBER,
  NUMBER_ATTRIBUTE7           NUMBER,
  NUMBER_ATTRIBUTE8           NUMBER,
  NUMBER_ATTRIBUTE9           NUMBER,
  NUMBER_ATTRIBUTE10          NUMBER,
  NUMBER_ATTRIBUTE11          NUMBER,
  NUMBER_ATTRIBUTE12          NUMBER,
  NUMBER_ATTRIBUTE13          NUMBER,
  NUMBER_ATTRIBUTE14          NUMBER,
  NUMBER_ATTRIBUTE15          NUMBER,
  DATE_ATTRIBUTE1             DATE,
  DATE_ATTRIBUTE2             DATE,
  DATE_ATTRIBUTE3             DATE,
  DATE_ATTRIBUTE4             DATE,
  DATE_ATTRIBUTE5             DATE,
  DATE_ATTRIBUTE6             DATE,
  DATE_ATTRIBUTE7             DATE,
  DATE_ATTRIBUTE8             DATE,
  DATE_ATTRIBUTE9             DATE,
  DATE_ATTRIBUTE10            DATE,
  DATE_ATTRIBUTE11            DATE,
  DATE_ATTRIBUTE12            DATE,
  DATE_ATTRIBUTE13            DATE,
  DATE_ATTRIBUTE14            DATE,
  DATE_ATTRIBUTE15            DATE,
  CATEGORY_ID                 NUMBER,
  CATEGORY_SET_ID             NUMBER,
  ITEM_STATUS                 VARCHAR2(10 BYTE),
  EMPLOYEE_NUMBER             VARCHAR2(30 BYTE),
  STRUCTURE_ID                NUMBER,
  BRAND_COUNT                 NUMBER,
  PROD_CATEGORY_COUNT         NUMBER,
  PROD_FAMILY_COUNT           NUMBER,
  COMP_COUNT                  NUMBER,
  COMP_MAIN_COUNT             NUMBER,
  ASSIGN_CATEGORY_COUNT       NUMBER,
  UOM_CODE                    VARCHAR2(25 BYTE),
  CREATED_BY_ORACLE_USER      NUMBER,
  LASTUPDATED_BY_ORACLE_USER  NUMBER,
  REQUEST_ID                  NUMBER
)
/
PROMPT create table APPS.XXAWR_PRODUCT_SF_ATTRIBUTE_STG
CREATE TABLE xxawr_product_sf_attribute_stg (
    sf_product_id                 VARCHAR2(150),
    sf_item_code                  VARCHAR2(40),
    record_id                     NUMBER
        GENERATED ALWAYS AS IDENTITY,
    six_month_sales               NUMBER,
    accessories_category          VARCHAR2(150),
    accessories_first_parameter   VARCHAR2(150),
    accessories_second_parameter  VARCHAR2(150),
    accessories_third_parameter   VARCHAR2(150),
    accessories_type_code         VARCHAR2(150),
    accessory_type                VARCHAR2(255),
    isactive                      VARCHAR2(3),
    actual_cost                   NUMBER,
    actual_landed_cost            NUMBER,
    additional_description        VARCHAR2(255),
    additional_description_code   VARCHAR2(4),
    additional_specs              VARCHAR2(150),
    application                   VARCHAR2(150),
    archived                      VARCHAR2(10),
    available_quantity            NUMBER,
    backup_hours                  VARCHAR2(150),
    beam_angle                    VARCHAR2(255),
    body_colors                   VARCHAR2(255),
    brand                         VARCHAR2(150),
    catalogue_reference           VARCHAR2(150),
    category                      VARCHAR2(150),
    cct                           VARCHAR2(150),
    charge_type                   VARCHAR2(150),
    code_1                        VARCHAR2(255),
    code_2                        VARCHAR2(255),
    color                         VARCHAR2(150),
    component_lumen_output        VARCHAR2(150),
    component_material            VARCHAR2(150),
    composition                   VARCHAR2(150),
    cost_price                    VARCHAR2(10),
    country_of_origin             VARCHAR2(150),
    createdbyid                   VARCHAR2(150),
    created_by_oracle_user_id     VARCHAR2(150),
    cri                           VARCHAR2(150),
    current_c                     VARCHAR2(150),
    deleted                       VARCHAR2(3),
    description                   VARCHAR2(500),
    diffuser                      VARCHAR2(150),
    dimensions                    VARCHAR2(150),
    displayurl                    VARCHAR2(150),
    driver_brand                  VARCHAR2(150),
    driver_controller_type        VARCHAR2(150),
    drivers                       VARCHAR2(255),
    estimated_cost                NUMBER,
    estimated_landed_cost         NUMBER,
    externaldatasourceid          VARCHAR2(150),
    externalid                    VARCHAR2(255),
    finish                        VARCHAR2(255),
    finished_goods_type           VARCHAR2(150),
    image_url                     VARCHAR2(255),
    in_transit_quantity           NUMBER,
    ip_rating                     VARCHAR2(150),
    item_code                     VARCHAR2(255),
    item_description              VARCHAR2(255),
    item_status                   VARCHAR2(150),
    item_type                     VARCHAR2(150),
    lastmodifiedbyid              VARCHAR2(150),
    last_sync_message             VARCHAR2(255),
    last_sync_timestamp           VARCHAR2(255),
    lastupdated_by_oracle_user_id NUMBER,
    led_brand                     VARCHAR2(150),
    lumen_efficacy                VARCHAR2(150),
    lumen_output                  VARCHAR2(255),
    manufactured_fg               VARCHAR2(3),
    margin                        NUMBER,
    material                      VARCHAR2(255),
    model_no                      VARCHAR2(150),
    month_stock                   NUMBER,
    no_of_cell                    VARCHAR2(150),
    notes                         VARCHAR2(150),
    description1                  VARCHAR2(4000),
    oracle_item_code              VARCHAR2(255),
    oracle_item_id                VARCHAR2(255),
    oracle_user_id                VARCHAR2(150),
    organization_code             VARCHAR2(255),
    other_details                 VARCHAR2(150),
    packaging                     VARCHAR2(150),
    pcb                           VARCHAR2(150),
    power_factor                  VARCHAR2(150),
    price_approved                VARCHAR2(3),
    price_verified                VARCHAR2(3),
    productcode                   VARCHAR2(255),
    currencyisocode               VARCHAR2(150),
    product_family                VARCHAR2(150),
    family                        VARCHAR2(150),
    product_image                 VARCHAR2(150),
    recordtypeid                  VARCHAR2(150),
    stockkeepingunit              VARCHAR2(180),
    proportion                    VARCHAR2(150),
    proposed                      VARCHAR2(3),
    quantityunitofmeasure         VARCHAR2(150),
    selling_price                 NUMBER,
    shortage_surplus              NUMBER,
    spare_digits                  VARCHAR2(150),
    specs                         VARCHAR2(150),
    sub_type                      VARCHAR2(150),
    supplier_cost                 NUMBER,
    name                          VARCHAR2(255),
    tech_category_label           VARCHAR2(200),
    tech_cct_label                VARCHAR2(200),
    tech_family_label             VARCHAR2(200),
    tech_uom_label                VARCHAR2(200),
    tech_wattage_label            VARCHAR2(200),
    tech_brand_label              VARCHAR2(100),
    tech_developername            VARCHAR2(150),
    tech_hasprd                   VARCHAR2(3),
    tech_inventory_item_flag      VARCHAR2(3),
    tech_lastsupplierid           VARCHAR2(255),
    terminal                      VARCHAR2(150),
    thickness                     VARCHAR2(150),
    type                          VARCHAR2(150),
    vat                           VARCHAR2(10),
    verified                      VARCHAR2(3),
    version                       VARCHAR2(150),
    voltage                       VARCHAR2(150),
    warranty                      VARCHAR2(150),
    wattage                       VARCHAR2(150)
)
/
-- PROMPT upgrade table XXAWR_PRODUCT_STG
-- BEGIN
 -- ad_zd_table.upgrade('XXAAC','XXAWR_PRODUCT_STG');
-- END; 
-- /
PROMPT create Index APPS.XXAWR_PRODUCT_STG_N1
CREATE INDEX APPS.XXAWR_PRODUCT_STG_N1 ON APPS.XXAWR_PRODUCT_STG
(OIC_INSTANCE_ID)
/
PROMPT create Index APPS.XXAWR_PRODUCT_STG_N2
CREATE INDEX APPS.XXAWR_PRODUCT_STG_N2 ON APPS.XXAWR_PRODUCT_STG
(STATUS)
/
PROMPT create Index APPS.XXAWR_PRODUCT_STG_N3
CREATE INDEX APPS.XXAWR_PRODUCT_STG_N3 ON APPS.XXAWR_PRODUCT_STG
(RECORD_ID)
/
SHOW ERROR; 
EXIT;