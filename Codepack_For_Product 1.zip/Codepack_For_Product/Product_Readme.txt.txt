1) Creating AOL Objects in EBS	--For DBA

	1.1): Move Codepack_for_Product folder to unix server.
	1.2): Give read,write and execute permission to codepack folder and files.
	1.3): Open the Codepack_for_product folder then navigate "/AOL_Objects" folder.
	1.4): Execute the script AOL_Deploy.sh using PuTTY.
	1.5): Upon successful completion of steps 1 access the Oracle application.

2) Creating DB Objects in EBS	--For DBA

	2.1): Move codepack_for_product folder to unix server.
	2.2): Give read,write and execute permission to codepack folder and files.
	2.3): Open the Codepack_for_product folder then navigate "/Database_Objects" folder.
	2.4): Execute the script DB_Deploy.sh using PuTTY.
	2.5): Upon successful completion of steps 1 access the Oracle application. 

3) In case of any failures, please reach out to Hemant.pokhriyal@intelloger.com.